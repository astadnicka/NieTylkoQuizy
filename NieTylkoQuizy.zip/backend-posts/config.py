MYSQL_HOST = 'mysql'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'rootpassword'
MYSQL_DB = 'quizdb'
MYSQL_CHARSET = 'utf8mb4'
MYSQL_INIT_COMMAND = 'SET NAMES utf8mb4 COLLATE utf8mb4_polish_ci'

