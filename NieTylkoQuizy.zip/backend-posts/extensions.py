from flask_mysqldb import MySQL

mysql = MySQL()
