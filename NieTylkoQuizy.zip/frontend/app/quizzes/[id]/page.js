import { use } from "react";
import QuizComponent from "@/components/QuizComponent";
import HoroscopeComponent from "@/components/HoroscopeComponent";
import PollComponent from "@/components/PollComponent";

export default function Page(promise) {
  const { params } = use(promise);

  const dataPromise = fetch(
    `${process.env.NEXT_PUBLIC_API_URL}/quizzes/${params.id}`,
    { cache: "no-store" }
  ).then((res) => res.json());

  const quiz = use(dataPromise);

  if (!quiz || !quiz.category) {
    return <div>Niepoprawne dane quizu</div>;
  }

  switch (quiz.category) {
    case "Quiz":
      return <QuizComponent quiz={quiz} />;
    case "Horoskop":
      return <HoroscopeComponent quiz={quiz} />;
    case "Głosowanie":
      return <PollComponent quiz={quiz} />;
    default:
      return <div>Nieznany typ quizu</div>;
  }
}
