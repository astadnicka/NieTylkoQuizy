'use client';

export default function UserLayout({ children }) {
  return (
    <>
      <p>Users</p>
      {children}
    </>
  );
}