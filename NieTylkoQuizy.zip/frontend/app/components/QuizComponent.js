// QuizComponent.js
'use client';

import { useState } from 'react';

export default function QuizComponent({ data }) {
  const [answers, setAnswers] = useState({});

  const handleAnswer = (questionId, optionId, isCorrect) => {
    setAnswers({
      ...answers,
      [questionId]: { selected: optionId, isCorrect },
    });
  };

  const score = Object.values(answers).filter((a) => a.isCorrect).length;
  const total = data.questions.length;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">{data.title}</h1>

      {data.questions.map((q) => (
        <div key={q.id} className="space-y-2">
          <h2 className="font-semibold">{q.text}</h2>
          <div className="flex flex-col gap-2">
            {q.options.map((opt) => {
              const selected = answers[q.id]?.selected;
              const isCorrect = opt.is_correct;
              const isSelected = selected === opt.id;

              let style = 'border p-2 rounded';
              if (selected) {
                if (isSelected && isCorrect) style += ' bg-green-300';
                else if (isSelected && !isCorrect) style += ' bg-red-300';
                else if (isCorrect) style += ' bg-green-100';
              }

              return (
                <button
                  key={opt.id}
                  onClick={() => handleAnswer(q.id, opt.id, opt.is_correct)}
                  disabled={!!selected}
                  className={style}
                >
                  {opt.text}
                </button>
              );
            })}
          </div>
        </div>
      ))}

      {Object.keys(answers).length === total && (
        <div className="mt-4 text-xl font-semibold">
          Twój wynik: {score} / {total} ({Math.round((score / total) * 100)}%)
        </div>
      )}
    </div>
  );
}
