'use client';

import { useEffect, useState } from 'react';

export default function PollComponent({ quizId }) {
  const [question, setQuestion] = useState(null);
  const [votedOptionId, setVotedOptionId] = useState(null);
  const [results, setResults] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:5001/quizzes/${quizId}`)
      .then(res => res.json())
      .then(data => {
        if (data.questions.length > 0) {
          setQuestion(data.questions[0]); // Zakładamy 1 pytanie na quiz typu głosowanie
        }
      });
  }, [quizId]);

  const handleVote = (optionId) => {
    setVotedOptionId(optionId);

    // Wysyłamy głos na backend
    fetch(`http://localhost:5001/polls/vote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ option_id: optionId })
    })
    .then(() => {
      // Po głosie, pobieramy wyniki
      fetch(`http://localhost:5001/polls/results/${question.id}`)
        .then(res => res.json())
        .then(data => setResults(data));
    });
  };

  return (
    <div className="max-w-xl mx-auto p-6 space-y-4 bg-white rounded-lg shadow">
      {question && (
        <>
          <h2 className="text-xl font-bold text-center">{question.text}</h2>

          {votedOptionId === null ? (
            <div className="space-y-2">
              {question.options.map(opt => (
                <button
                  key={opt.id}
                  onClick={() => handleVote(opt.id)}
                  className="block w-full p-3 text-left border rounded hover:bg-gray-100"
                >
                  {opt.text}
                </button>
              ))}
            </div>
          ) : results ? (
            <div className="space-y-3">
              {results.map(res => {
                const percentage = res.votes > 0
                  ? ((res.votes / results.reduce((a, b) => a + b.votes, 0)) * 100).toFixed(1)
                  : 0;
                return (
                  <div key={res.option_id}>
                    <div className="flex justify-between">
                      <span>{res.option_text}</span>
                      <span>{res.votes} głosów ({percentage}%)</span>
                    </div>
                    <div className="w-full bg-gray-200 h-3 rounded">
                      <div
                        className="bg-blue-500 h-3 rounded"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p>Ładowanie wyników...</p>
          )}
        </>
      )}
    </div>
  );
}
