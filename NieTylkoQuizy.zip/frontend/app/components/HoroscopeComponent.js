'use client';

import { useEffect, useState } from 'react';

const zodiacSigns = [
  'Baran', 'Byk', 'Bliźnięta', 'Rak',
  'Lew', 'Panna', 'Waga', 'Skorpion',
  'Strzelec', 'Koziorożec', 'Wodnik', 'Ryby'
];

export default function HoroscopeComponent({ quizId }) {
  const [horoscopes, setHoroscopes] = useState([]);
  const [selectedSign, setSelectedSign] = useState(null);
  const [selectedText, setSelectedText] = useState('');

  useEffect(() => {
    // Zakładamy, że dla horoskopu pytanie to znak zodiaku, a options[0].text to przepowiednia
    fetch(`http://localhost:5001/quizzes/${quizId}`)
      .then(res => res.json())
      .then(data => {
        setHoroscopes(data.questions); // jeden question = jeden znak zodiaku
      })
      .catch(err => console.error('Błąd pobierania horoskopów:', err));
  }, [quizId]);

  const handleClick = (sign) => {
    const found = horoscopes.find(q => q.text.toLowerCase() === sign.toLowerCase());
    if (found && found.options.length > 0) {
      setSelectedSign(sign);
      setSelectedText(found.options[0].text);
    }
  };

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="grid grid-cols-3 md:grid-cols-4 gap-4">
        {zodiacSigns.map(sign => (
          <button
            key={sign}
            onClick={() => handleClick(sign)}
            className="bg-indigo-100 hover:bg-indigo-200 p-4 rounded-xl text-center shadow"
          >
            {sign}
          </button>
        ))}
      </div>

      {selectedSign && (
        <div className="mt-6 max-w-xl text-center p-6 border rounded-xl bg-white shadow">
          <h2 className="text-xl font-bold mb-2">{selectedSign}</h2>
          <p>{selectedText}</p>
        </div>
      )}
    </div>
  );
}
