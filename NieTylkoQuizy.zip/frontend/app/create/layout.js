'use client';

export default function RootLayout({ children }) {
  return (
    <>
      <p>stworz swoj quiz</p>
      {children}
    </>
  );
}