/** @type {import('next').NextConfig} */
const nextConfig = {
  // webpackDevMiddleware: config => {
  //   config.watchOptions = {
  //     poll: 500,            // sprawdzaj co 1000ms
  //     aggregateTimeout: 300, // czekaj 300ms na kolejne zmiany
  //   };
  //   return config;
  // },
};

export default nextConfig;