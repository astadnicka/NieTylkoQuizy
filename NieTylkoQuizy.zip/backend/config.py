MYSQL_HOST = 'mysql'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'rootpassword'
MYSQL_DB = 'quizdb'
